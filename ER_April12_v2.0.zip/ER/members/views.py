from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView, LogoutView
from django.contrib import messages
from django.urls import reverse_lazy
from .models import Patient
from django.contrib.auth.forms import AuthenticationForm

# Create views here.

def index(request):
    return render(request, 'login.html')

class CustomLoginView(LoginView):
    template_name = 'login.html'
    success_url = reverse_lazy('dashboard')  # 'dashboard' should replace to -> desired URL

class CustomLogoutView(LogoutView):
    next_page = reverse_lazy('login')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def patient_list(request):
    patients = Patient.objects.all()  # Fetch all patients
    context = {'patients': patients}
    return render(request, 'patient_list.html', context)

def new_patient(request):
    print("new_patient view accessed!")
    if request.method == 'POST':
        form_data = request.POST

        try:
            new_patient = Patient.objects.create(
                first_name=form_data['first_name'],
                last_name=form_data['last_name'],
                date_of_birth=form_data['dob'],
                address=form_data['address'],
                phone_number=form_data['phone_number'],
                emergency_contact_1_name=form_data['ec1_name'],
                emergency_contact_1_relationship=form_data['ec1_rel'],
                emergency_contact_1_phone=form_data['ec1_phone'],
                emergency_contact_2_name=form_data['ec2_name'],
                emergency_contact_2_relationship=form_data['ec2_rel'],
                emergency_contact_2_phone=form_data['ec2_phone'],
                reason_for_visit=form_data['visit_reason'],
                allergies=form_data['allergies'],
                current_medical_problems=form_data['medical_problems'],
                current_medications=form_data['medications'],
                insurance=form_data['insurance'] == 'True',
            )
            messages.success(request, 'Patient information submitted successfully!')
            return redirect('new_patient')

        except Exception as e:
            messages.error(request, f'Failed to save patient data: {e}')
            return render(request, 'new_patient.html', {'form_data': form_data})

    else:
        return render(request, 'new_patient.html')
def register(request):
    return render(request, 'register.html')
