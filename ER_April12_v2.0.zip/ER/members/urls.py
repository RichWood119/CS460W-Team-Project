from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    path('', views.index, name='index'),
    path('patients/', views.patient_list, name='patient_list'),
    path('new_patient/', views.new_patient, name='new_patient'),
    path('register/', views.register, name='register'),
]
