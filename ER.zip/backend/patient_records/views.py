from django.shortcuts import render
from .models import Patient  # Assuming you have a Patient model

def patient_list(request):
  patients = Patient.objects.all()  # Get all patients
  context = {'patients': patients}
  return render(request, 'patient_records/patient_list.html', context)
