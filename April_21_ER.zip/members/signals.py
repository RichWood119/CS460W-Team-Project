from django.db.models.signals import post_save
from django.dispatch import receiver
from django.conf import settings

@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_staff_instances(sender, instance=None, created=False, **kwargs):
    if created:
        profile = instance.profile
        if profile.role == 'DOC':
            from members.models import Doctor
            Doctor.objects.create(user=instance)
        elif profile.role == 'NUR':
            from members.models import Nurse
            Nurse.objects.create(user=instance)
        elif profile.role == 'ADM':
            from members.models import AdmittingStaff
            AdmittingStaff.objects.create(user=instance)
        elif profile.role == 'BIL':
            from members.models import BillingStaff
            BillingStaff.objects.create(user=instance)
