from django.urls import path
from . import views
from .views import UserRegistrationView

urlpatterns = [
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', views.CustomLogoutView.as_view(), name='logout'),
    path('', views.index, name='index'),
    path('patients/', views.patient_list, name='patient_list'),
    path('new_patient/', views.new_patient, name='new_patient'),
    path('register/', UserRegistrationView.as_view(), name='register'),
    path('doctor/', views.doctor, name='doctor'),
    path('billing_staff/', views.billing_staff, name='billing_staff'),
    path('admitting_staff/', views.admitting_staff, name='admitting_staff'),
    path('nurse/', views.nurse, name='nurse'),
    path('dashboard/', views.dashboard, name='dashboard'),
]
