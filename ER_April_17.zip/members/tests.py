from django.test import TestCase
from django.contrib.auth.models import User

class LoginTest(TestCase):

    def test_login_with_valid_credentials(self):
        """Test successful login with valid username and password."""
        user = User.objects.create_user(username='test_user', password='secret_password')

        login_data = {'username': 'test_user', 'password': 'secret_password'}

        response = self.client.post('/login/', login_data)

        self.assertEqual(response.status_code, 302)
        self.assertRedirected(response, '/dashboard/')
