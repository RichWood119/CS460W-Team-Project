from django.contrib import admin
from .models import Patient, Visit, Diagnosis, TestResult, Medication

# admin.site.register(Patient)

@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'phone_number')
    search_fields = ('last_name', )

@admin.register(Visit)
class VisitAdmin(admin.ModelAdmin):
    list_filter = ('discharge_status', 'doctor')

    # Inline definitions
    class DiagnosisInline(admin.TabularInline):
        model = Diagnosis
        extra = 1  # Provide space for an extra, empty row

    class TestResultInline(admin.TabularInline):
        model = TestResult
        extra = 1

    class MedicationInline(admin.TabularInline):
        model = Medication
        extra = 1

    inlines = [DiagnosisInline, TestResultInline, MedicationInline]
