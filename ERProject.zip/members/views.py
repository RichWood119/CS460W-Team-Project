from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView, LogoutView
from django.urls import reverse_lazy
from .models import Patient
from django.contrib.auth.forms import AuthenticationForm

# Create views here.
from django.http import HttpResponse

def members(request):
    return HttpResponse("Hello world!")

def index(request):
    return render(request, 'login.html')

class CustomLoginView(LoginView):
    template_name = 'login.html'
    success_url = reverse_lazy('dashboard')  # 'dashboard' should replace to -> desired URL

class CustomLogoutView(LogoutView):
    next_page = reverse_lazy('login')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            return redirect('dashboard')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def patient_list(request):
    patients = Patient.objects.all()  # Fetch all patients
    context = {'patients': patients}
    return render(request, 'members/patient_list.html', context)

