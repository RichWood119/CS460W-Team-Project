import datetime, random
from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractUser

def generate_next_patient_id():
    last_patient = Patient.objects.all().order_by('-patientID').first()
    if not last_patient:
        return 1000
    return last_patient.patientID + 1

class Patient(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    # user = models.OneToOneField(User, on_delete=models.CASCADE)
    patientID = models.AutoField(
        default=generate_next_patient_id,
        primary_key=True,
        serialize=False,
    )
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    date_of_birth = models.DateField()
    address = models.CharField(max_length=200)
    phone_number = models.CharField(max_length=20)
    emergency_contact_1_name = models.CharField(max_length=50)
    emergency_contact_1_relationship = models.CharField(max_length=50)
    emergency_contact_1_phone = models.CharField(max_length=20)
    emergency_contact_2_name = models.CharField(max_length=50)
    emergency_contact_2_relationship = models.CharField(max_length=50)
    emergency_contact_2_phone = models.CharField(max_length=20)
    reason_for_visit = models.TextField()
    allergies = models.TextField()
    current_medical_problems = models.TextField()
    current_medications = models.TextField()
    insurance = models.BooleanField()
    def __str__(self):
      return f"{self.first_name} {self.last_name} (id: {self.patientID})"

class User(AbstractUser):
    DOCTOR = 'DOC'
    NURSE = 'NUR'
    ADMITTING_STAFF = 'ADM'
    BILLING_STAFF = 'BIL'
    ROLE_CHOICES = (
        (DOCTOR, 'Doctor'),
        (NURSE, 'Nurse'),
        (ADMITTING_STAFF, 'Admitting Staff'),
        (BILLING_STAFF, 'Billing Staff'),
    )
    role = models.CharField(max_length=4, choices=ROLE_CHOICES, default='ADM')

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.CharField(max_length=4, choices=User.ROLE_CHOICES)

class PatientCheckIn(models.Model):
    date_time = models.DateTimeField()
    patient = models.ForeignKey('Patient', on_delete=models.CASCADE)
    doctor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='doctor_checkins')
    nurse = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='nurse_checkins')
    status = models.CharField(max_length=20, choices=[('Open', 'Open'), ('Closed', 'Closed')], default='Open')

class Doctor(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

class Nurse(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

class AdmittingStaff(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

class BillingStaff(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)

class TestType(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        return self.name

class NursePatientInfo(models.Model):
    heart_rate = models.CharField(max_length=10)
    blood_pressure = models.CharField(max_length=10)
    test_types = models.ManyToManyField(TestType)
    notes = models.TextField()
    dischargeNotes = models.TextField()
    patient_check_in = models.ForeignKey('members.PatientCheckIn', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=datetime.datetime.now)

class TestResult(models.Model):
    nurse_patient_info = models.ForeignKey(NursePatientInfo, on_delete=models.CASCADE, related_name='test_results')
    test_type = models.ForeignKey(TestType, on_delete=models.CASCADE)
    result = models.CharField(max_length=255)
    timestamp = models.DateTimeField(auto_now_add=True)

    def generate_random_result(self):
        results = ['Normal', 'Abnormal']
        self.result = random.choice(results)
        self.save()

    def __str__(self):
        return f"{self.test_type.name} - {self.result}"

class Diagnosis(models.Model):
    DIAGNOSIS_CHOICES = [
        ('KD', 'Kidney Disease'),
        ('LD', 'Liver Disease'),
        ('AN', 'Anemia'),
        ('BF', 'Bone Fracture'),
        ('HD', 'Heart Disease'),
    ]
    name = models.CharField(max_length=3, choices=DIAGNOSIS_CHOICES)
    def __str__(self):
      return self.get_name_display()

class Prescription(models.Model):
    DRUG_CHOICES = [
        ('PEN', 'Penicillin'),
        ('AMX', 'Amoxicillin'),
        ('IBU', 'Ibuprofen'),
        ('PRE', 'Prednisone'),
        ('LIS', 'Lisinopril'),
        ('FUR', 'Furosemide'),
        ('LAC', 'Lactulose'),
        ('SPI', 'Spironolactone'),
        ('OXY', 'Oxycodone'),
    ]
    ROUTE_CHOICES = [
        ('IM', 'Intramuscular'),
        ('IV', 'Intravascular'),
        ('SC', 'Subcutaneous'),
        ('ORA', 'Oral'),
    ]
    drug = models.CharField(max_length=50, choices=DRUG_CHOICES)
    dosage = models.CharField(max_length=50)
    route = models.CharField(max_length=3, choices=ROUTE_CHOICES)
    amount_per_day = models.IntegerField()
    prescription_date = models.DateTimeField(auto_now_add=True)
    price = models.DecimalField(max_digits=6, decimal_places=2)

    def __str__(self):
        drug_name = dict(self.DRUG_CHOICES).get(self.drug, 'Unknown drug')
        route_name = dict(self.ROUTE_CHOICES).get(self.route, 'Unknown route')
        return f"{drug_name} - {self.dosage} - {route_name} - {self.amount_per_day}x per day"

class DoctorPatientInfo(models.Model):
    heart_rate = models.CharField(max_length=10)
    blood_pressure = models.CharField(max_length=10)
    notes = models.TextField()
    diagnosis = models.ForeignKey(Diagnosis, on_delete=models.CASCADE)
    prescriptions = models.ManyToManyField('Prescription', related_name='doctor_infos', blank=True)
    dischargeNotes = models.TextField(default="")
    patient_check_in = models.ForeignKey(PatientCheckIn, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(default=datetime.datetime.now)
