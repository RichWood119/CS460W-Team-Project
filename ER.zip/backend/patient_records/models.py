from django.db import models

class Patient(models.Model):
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    date_of_birth = models.DateField()
    # Additional fields from your admitting class diagram
    address = models.CharField(max_length=100, blank=True)  # Optional (blank=True allows for empty values)
    phone_number = models.CharField(max_length=15)  # Consider using a library for phone number formatting
    emergency_contact_name = models.CharField(max_length=50)
    emergency_contact_phone_number = models.CharField(max_length=15)
    medical_history = models.TextField(blank=True)  # Text field for medical history
    allergies = models.CharField(max_length=200, blank=True)  # Comma-separated list of allergies

